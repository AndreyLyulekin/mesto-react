export const eventNames = {
   openPopup: "openPopup",
   clearPopups: "cleaPopups",
   selectedCard: "selectedCard",
   clearSelectedCard: "clearSelectedCard",
};
