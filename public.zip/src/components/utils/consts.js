export const apiCredentials = {
   baseUrl: "https://mesto.nomoreparties.co/v1/cohort-57",
   token: "8e3ad974-ef23-4fdc-9e86-84348071758d",
};
